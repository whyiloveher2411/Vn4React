var config = {
    paths:{
        judila_widget: 'Judila_Widget/js/flickity.pkgd.min',
    },
    shim: {
        judila_widget: ['jquery']
    }
};
