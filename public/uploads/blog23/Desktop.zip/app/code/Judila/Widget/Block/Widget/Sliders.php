<?php 
namespace Judila\Widget\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface; 
 
class Sliders extends Template implements BlockInterface {

	// protected $_template = "widget/sliders.phtml";

	protected function _construct()
	{
		parent::_construct();
		$this->setTemplate('widget/sliders.phtml');

		$om = \Magento\Framework\App\ObjectManager::getInstance();
		$page = $om->get('Magento\Framework\View\Page\Config');
		$page->addPageAsset('Judila_Widget::css/judila-home.css');

	}


}