<?php 
namespace Judila\Widget\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface; 
 
class NewArrivals extends Template implements BlockInterface {

	protected $_template = "widget/new-arrivals.phtml";
}