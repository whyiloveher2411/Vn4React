<?php
namespace Judila\Widget\Model;

use \Magento\Widget\Model\Widget as BaseWidget;

class Widget
{
    public function beforeGetWidgetDeclaration(BaseWidget $subject, $type, $params = [], $asIs = true)
    {
        // I rather do a check for a specific parameters
        
        $widgetList = [
            'Judila\Widget\Block\Widget\Categories'=>
                [
                    'silider_image_pc_1', 
                    'silider_image_pc_2', 
                    'silider_image_pc_3', 
                    'silider_image_mb_1', 
                    'silider_image_mb_2', 
                    'silider_image_mb_3', 
                    
                ],
            'Judila\Widget\Block\Widget\Commitment'=>[
                    'image_1', 
                    'image_2', 
                    'image_3', 
                    'image_4', 
                ],
            'Judila\Widget\Block\Widget\HotItems'=>[
                    'thumbnail_pc_1',
                    'thumbnail_pc_2',
                    'thumbnail_pc_3',
                    'thumbnail_pc_4',
                    'thumbnail_mb_1',
                    'thumbnail_mb_2',
                    'thumbnail_mb_3',
                    'thumbnail_mb_4',
                ],
            'Judila\Widget\Block\Widget\Sliders'=>[
                    'silider_image_1',
                    'silider_image_2',
                    'silider_image_3',
                    'silider_image_4',
                    'silider_image_5',
                ],
            'Judila\Widget\Block\Widget\Testerminal'=>[
                    'avata_1',
                    'avata_2',
                    'avata_3',
                ],

        ];
        // var_dump($type);

        // die(1);

        if( isset($widgetList[$type])  ){

            foreach( $widgetList[$type] as $keyImage ){

                if(  key_exists($keyImage, $params) && $params[$keyImage]) {

                    $url = $params[$keyImage];

                    if(strpos($url,'/directive/___directive/') !== false) {

                        $parts = explode('/', $url);
                        $key   = array_search("___directive", $parts);
                        if($key !== false) {

                            $url = $parts[$key+1];
                            $url = base64_decode(strtr($url, '-_,', '+/='));

                            $parts = explode('"', $url);
                            $key   = array_search("{{media url=", $parts);
                            $url   = $parts[$key+1];

                            $params[$keyImage] = $url;
                        }
                    }
                }
            }
        }

        return array($type, $params, $asIs);
    }
}