<?php 
namespace Judila\Widget\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface; 
 
class Commitment extends Template implements BlockInterface {

	protected $_template = "widget/commitment.phtml";
}