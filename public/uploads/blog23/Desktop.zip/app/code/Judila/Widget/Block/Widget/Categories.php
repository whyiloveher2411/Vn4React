<?php 
namespace Judila\Widget\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface; 
 
class Categories extends Template implements BlockInterface {

	protected $_template = "widget/categories.phtml";
}