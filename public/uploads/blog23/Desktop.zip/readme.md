#instructions

- Prepare source code: Copy app zip to app (module, theme)
- Compile code: `php bin/magento setup:di:compile`
- set upgrade: `php bin/magento setup:upgrade`
- deloy asset: `php bin/magento setup:static-content:deploy -f`


