<div disabled  class="editor-content data-visual content-visual height_textare_{!!$key!!}" style="border:1px solid #cecece;padding: 5px;word-wrap: break-word;max-height: 200px;overflow: auto;">
  {!!$value!!}
</div>